Advanced Villages - Bedrock Modpack (starter)
===============================================
This package contains a behavior pack and a resource pack starter designed for Minecraft Bedrock 1.21.120.

Features included (starter):
- Improved villager behavior (conservative, achievements-safe).
- Iron Golem behavior adjustments to avoid village disappearing when a golem dies.
- Demo functions for spawning villagers.
- Placeholder structure files for biome-specific beautiful houses (replace these with actual .mcstructure files using structure blocks).
- No Experimental Gameplay required — achievements remain enabled.

IMPORTANT: This is a starter pack. To get fully beautiful villages (as in Better Villages mod for Java), you should import or create .mcstructure files using structure blocks and replace the placeholder files in the 'structures' folder.
