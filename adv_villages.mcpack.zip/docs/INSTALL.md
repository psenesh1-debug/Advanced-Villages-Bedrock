INSTALLATION (Windows / Android / iOS)
1) Unzip adv_villages_modpack.zip.
2) Copy 'behavior_packs/adv_villages_behavior' into your com.mojang/behavior_packs folder.
3) Copy 'resource_packs/adv_villages_resource' into your com.mojang/resource_packs folder.
4) In Minecraft Bedrock, create a new world. Do NOT enable Experimental Gameplay (to keep achievements).
5) In World Settings -> Behavior Packs / Resource Packs, add the Advanced Villages packs to the world and enable them.
6) Use /function adv:spawn_demo_village to test (or place structure blocks and load your adv_<biome>_house.mcstructure once you replace placeholders).
Notes:
- Structure placeholders in /structures are .txt placeholders. Replace them with actual .mcstructure binary files created in-game via structure blocks.
- This pack deliberately uses only non-experimental features to keep achievements enabled.
